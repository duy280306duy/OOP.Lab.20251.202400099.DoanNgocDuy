package ff;

public class DigitalVideoDisc {
	private int id; 
	private static int nbDigitalVideoDiscs = 0;
	private String title;
	private String category;
	private String director;
	private int length;
	private float cost;
	public String getTitle() {
		return title;
	public DigitalVideoDisc(String title, String category, String director, int length, float cost) {
	       this.title = title;
	       this.category = category;
	       this.director = director;
	       this.length = length;
	       this.cost = cost;
	        
	       nbDigitalVideoDiscs++;
	       this.id = nbDigitalVideoDiscs;
	    }
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getDirector() {
		return director;
	}
	public void setDirector(String director) {
		this.director = director;
	}
	public int getLength() {
		return length;
	}
	public void setLength(int length) {
		this.length = length;
	}
	public float getCost() {
		return cost;
	}
	public void setCost(float cost) {
		this.cost = cost;
	}
	public DigitalVideoDisc(String title) {
		super();
		this.title = title;
	}
	public DigitalVideoDisc(String title, String category, float cost) {
		super();
		this.title = title;
		this.category = category;
		this.cost = cost;
	}
	public DigitalVideoDisc(String title, String category, String director, float cost) {
		super();
		this.title = title;
		this.category = category;
		this.director = director;
		this.cost = cost;
	}
	public DigitalVideoDisc(String title, String category, String director, int length, float cost) {
		super();
		this.title = title;
		this.category = category;
		this.director = director;
		this.length = length;
		this.cost = cost;
	}
	public boolean isMatch(String title) {
        if (title == null) return false;
        return this.title.toLowerCase().contains(title.toLowerCase());
    }
   
    
    public String toString() {
        return "DVD - [" + id + "] - [" + title + "] - [" + category + "] - [" +
                director + "] - [" + length + " mins] : [" + cost + " $]";
    }

}
